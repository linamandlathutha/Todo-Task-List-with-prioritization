﻿using Microsoft.AspNetCore.SignalR;

public class TaskHub : Hub
{
    public async Task SendMessage(string taskName)
    {
        await Clients.All.SendAsync("ReceiveMessage", taskName);
    }
}
